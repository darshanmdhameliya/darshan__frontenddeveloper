export interface IGroup {
   _id?:String,
   name:String,
   createdAt?:Date,
   updatedAt?:Date,
}
